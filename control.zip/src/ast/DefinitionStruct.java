/**
 * @generated VGen (for ANTLR) 1.7.2
 */

package ast;

import java.util.*;
import org.antlr.v4.runtime.*;

import visitor.*;

//	definitionStruct:definition -> name:String  structFields:definitionVariable*

public class DefinitionStruct extends AbstractDefinition {

	public DefinitionStruct(String name, List<DefinitionVariable> structFields) {
		this.name = name;
		this.structFields = structFields;

       // Lo siguiente se puede borrar si no se quiere la posicion en el fichero.
       // Obtiene la linea/columna a partir de las de los hijos.
       setPositions(structFields);
	}

	public DefinitionStruct(Object name, Object structFields) {
		this.name = (name instanceof Token) ? ((Token)name).getText() : (String) name;
		this.structFields = this.<DefinitionVariable>getAstFromContexts(structFields);

       // Lo siguiente se puede borrar si no se quiere la posicion en el fichero.
       // Obtiene la linea/columna a partir de las de los hijos.
       setPositions(name, structFields);
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public List<DefinitionVariable> getStructFields() {
		return structFields;
	}
	public void setStructFields(List<DefinitionVariable> structFields) {
		this.structFields = structFields;
	}

	@Override
	public Object accept(Visitor v, Object param) { 
		return v.visit(this, param);
	}

	private String name;
	private List<DefinitionVariable> structFields;

	public String toString() {
       return "{name:" + getName() + ", structFields:" + getStructFields() + "}";
   }
}
